"""
ARN Pipeline Configuration
Edit these values before running.
"""
from pathlib import Path

# ─── Anthropic ────────────────────────────────────────────────────────────────
ANTHROPIC_API_KEY = "YOUR_API_KEY_HERE"   # or set env var ANTHROPIC_API_KEY
CLAUDE_MODEL      = "claude-opus-4-6"

# ─── Paths ────────────────────────────────────────────────────────────────────
BASE_DIR         = Path(__file__).parent
RAW_PDF_DIR      = BASE_DIR / "raw_pdfs"          # downloaded PDFs land here
PROCESSED_DIR    = BASE_DIR / "processed"         # extracted text as .txt
OBSIDIAN_VAULT   = BASE_DIR / "obsidian_vault"    # final .md files

# Sub-folders inside the vault
VAULT_ARN        = OBSIDIAN_VAULT / "ARN"          # one file per decision
VAULT_LAW        = OBSIDIAN_VAULT / "Lagstiftning" # statute section stubs
VAULT_CONCEPTS   = OBSIDIAN_VAULT / "Koncept"      # legal concept stubs
VAULT_INDEX      = OBSIDIAN_VAULT / "Index"        # category index pages

# ─── Scraper ──────────────────────────────────────────────────────────────────
ARN_BASE_URL       = "https://www.arn.se"
ARN_DECISIONS_PAGE = "/om-arn/vagledande-beslut/"
ARN_PDF_BASE       = "https://www.arn.se/globalassets/extern/pdfer"

# Only scrape these categories (None = scrape all)
CATEGORY_FILTER = ["Försäkring", "Forsakring", "Bo", "Bostad"]

RATE_LIMIT_SECONDS = 1.5   # be polite to the public authority
MAX_CONCURRENT     = 3     # parallel downloads
USER_AGENT         = "LegalResearchBot/1.0 (property insurance research; update with your contact)"

# ─── LLM Processing ───────────────────────────────────────────────────────────
# Minimum text length to attempt LLM processing (skip empty/corrupt PDFs)
MIN_TEXT_LENGTH = 200

# How many decisions to process in one run (None = all)
PROCESS_LIMIT = None
