"""
scraper.py — Downloads ARN decision PDFs from arn.se

Fetches the vägledande beslut index page, extracts all PDF links,
filters by category, then downloads each PDF with polite rate limiting.
"""

import asyncio
import re
from pathlib import Path
from dataclasses import dataclass, field
from typing import Optional

import httpx
from rich.console import Console
from rich.progress import Progress, SpinnerColumn, TextColumn, BarColumn, TaskProgressColumn

console = Console()


@dataclass
class DecisionMeta:
    """Metadata extracted from the ARN index page for one decision."""
    case_id:    str
    category:   str
    date:       str
    summary:    str
    pdf_url:    str
    year:       str = field(init=False)

    def __post_init__(self):
        self.year = self.date[:4] if self.date else "unknown"

    @property
    def safe_id(self) -> str:
        return self.case_id.replace("/", "_").replace(" ", "_")

    @property
    def pdf_filename(self) -> str:
        return f"{self.safe_id}.pdf"


def parse_decisions_from_html(html: str) -> list[DecisionMeta]:
    """
    Parse the vägledande beslut page HTML (rendered as markdown by httpx).
    Each decision block looks like:

        ### Försäkring, Beslut 2022-10-24
        Some summary text...
        [Referat 2021-17230](https://...pdf)
    """
    decisions = []

    # Split on markdown H3 headings that match decision pattern
    blocks = re.split(r'(?=###\s+\w[^\n]+[Bb]eslut\s+\d{4})', html)

    for block in blocks:
        heading = re.search(
            r'###\s+([^,\n]+),\s*[Bb]eslut\s+(\d{4}-\d{2}-\d{2})',
            block
        )
        pdf_link = re.search(
            r'\[(?:Referat|Ärendereferat)\s+([\d-]+)\]\((https://[^\)]+\.pdf)\)',
            block,
            re.IGNORECASE
        )

        if not heading or not pdf_link:
            continue

        category = heading.group(1).strip()
        date     = heading.group(2).strip()
        case_id  = pdf_link.group(1).strip()
        pdf_url  = pdf_link.group(2).strip()

        # Summary: text between heading line and PDF link
        summary_raw = block[heading.end():pdf_link.start()]
        summary = re.sub(r'\s+', ' ', summary_raw).strip()
        # Remove markdown artifacts
        summary = re.sub(r'\[.*?\]\(.*?\)', '', summary).strip()

        decisions.append(DecisionMeta(
            case_id=case_id,
            category=category,
            date=date,
            summary=summary,
            pdf_url=pdf_url,
        ))

    return decisions


def filter_by_category(
    decisions: list[DecisionMeta],
    category_filter: Optional[list[str]]
) -> list[DecisionMeta]:
    """Keep only decisions matching the category filter (case-insensitive)."""
    if not category_filter:
        return decisions

    normalized = [c.lower() for c in category_filter]

    def matches(d: DecisionMeta) -> bool:
        cat = d.category.lower()
        return any(f in cat for f in normalized)

    return [d for d in decisions if matches(d)]


async def fetch_html(client: httpx.AsyncClient, url: str, rate: float) -> str:
    await asyncio.sleep(rate)
    resp = await client.get(url)
    resp.raise_for_status()
    return resp.text


async def download_pdf(
    client: httpx.AsyncClient,
    decision: DecisionMeta,
    out_dir: Path,
    rate: float,
    semaphore: asyncio.Semaphore,
) -> tuple[DecisionMeta, bool]:
    """Download one PDF. Returns (decision, success)."""
    out_path = out_dir / decision.pdf_filename

    if out_path.exists():
        return decision, True   # already downloaded

    async with semaphore:
        await asyncio.sleep(rate)
        try:
            resp = await client.get(decision.pdf_url)
            resp.raise_for_status()
            out_path.write_bytes(resp.content)
            return decision, True
        except Exception as e:
            console.print(f"[red]✗ {decision.case_id}: {e}[/red]")
            return decision, False


async def scrape(
    base_url: str,
    decisions_page: str,
    out_dir: Path,
    category_filter: Optional[list[str]],
    rate_limit: float,
    max_concurrent: int,
    user_agent: str,
) -> list[tuple[DecisionMeta, Path]]:
    """
    Full scrape run.
    Returns list of (DecisionMeta, pdf_path) for all successfully downloaded PDFs.
    """
    out_dir.mkdir(parents=True, exist_ok=True)
    headers = {"User-Agent": user_agent}

    async with httpx.AsyncClient(
        base_url=base_url,
        headers=headers,
        timeout=60,
        follow_redirects=True,
    ) as client:

        # 1. Fetch index
        console.print(f"[cyan]Fetching ARN index from {base_url + decisions_page}[/cyan]")
        html = await fetch_html(client, decisions_page, rate=0)

        # 2. Parse all decisions
        all_decisions = parse_decisions_from_html(html)
        console.print(f"[green]Found {len(all_decisions)} total decisions[/green]")

        # 3. Filter
        decisions = filter_by_category(all_decisions, category_filter)
        console.print(f"[green]After category filter: {len(decisions)} decisions[/green]")

        if not decisions:
            console.print("[yellow]No decisions matched filter. Check CATEGORY_FILTER in config.py[/yellow]")
            return []

        # 4. Download PDFs with concurrency limit
        semaphore = asyncio.Semaphore(max_concurrent)
        tasks = [
            download_pdf(client, d, out_dir, rate_limit, semaphore)
            for d in decisions
        ]

        results = []
        with Progress(
            SpinnerColumn(),
            TextColumn("[progress.description]{task.description}"),
            BarColumn(),
            TaskProgressColumn(),
        ) as progress:
            task = progress.add_task("Downloading PDFs...", total=len(tasks))

            for coro in asyncio.as_completed(tasks):
                decision, success = await coro
                progress.advance(task)
                if success:
                    pdf_path = out_dir / decision.pdf_filename
                    results.append((decision, pdf_path))

    console.print(f"[bold green]✓ Downloaded {len(results)}/{len(decisions)} PDFs[/bold green]")
    return results
